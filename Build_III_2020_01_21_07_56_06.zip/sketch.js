function setup() {
  createCanvas(600, 600);
  background(255, 204, 0);
  happy = createA('https://www.youtube.com/embed/videoseries?list=PLZHDu8yk0UeClZE3W2URJJa0TgFnOKgjk',"happy");
  calm = createA('https://www.youtube.com/embed/videoseries?list=PLZHDu8yk0UeA7IkcpiX9H7rwsAN-WE-Sm',"calm");
  sad = createA('https://www.youtube.com/embed/videoseries?list=PLZHDu8yk0UeCSdgqBssdj_DLUkyDOdEOh',"sad");
  happy.position(180, 19);
  happy.mousePressed();
  happy.style('font-size', '100px');
  calm.position(200,250);
  calm.mousePressed();
  calm.style('font-size', '100px');
  sad.position(240,450)
  sad.mousePressed();
  sad.style('font-size', '100px');
}
let cOffset = 0;
function draw() {
	const inc = height/100;
	colorMode(HSB);
	
	for(let y = 0; y < height; y += inc) {
		let h = (y / height) * 360;
		fill(abs(h+cOffset)%360, 100, 100);
		noStroke();
		rect(0, y-inc, width, y);
	}
	
	cOffset -= 5;
}